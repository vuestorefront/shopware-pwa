## This is a placeholder file

Place your PWA specific resources and assets in this directory.

Whenever you activate or deactivate a plugin, Shopware will parse this directory (`src/Resources/app/pwa`) for files and copy them into a static .zip file.

You can manually execute this step using

```sh
$ bin/console pwa:dump-plugins
```